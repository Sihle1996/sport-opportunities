package com.example.sporttrials;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SporttrialsApplicationTests {

	@Test
	void contextLoads() {
	}

}
