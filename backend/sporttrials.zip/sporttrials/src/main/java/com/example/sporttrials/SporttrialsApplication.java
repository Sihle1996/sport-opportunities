package com.example.sporttrials;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SporttrialsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SporttrialsApplication.class, args);
	}

}
